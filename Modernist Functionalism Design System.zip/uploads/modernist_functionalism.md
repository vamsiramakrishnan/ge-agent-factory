---
name: Modernist Functionalism
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e4e2e1'
  on-surface: '#1b1c1c'
  on-surface-variant: '#424752'
  inverse-surface: '#303030'
  inverse-on-surface: '#f3f0f0'
  outline: '#727784'
  outline-variant: '#c2c6d4'
  surface-tint: '#0d5bbc'
  primary: '#00408b'
  on-primary: '#ffffff'
  primary-container: '#0057b8'
  on-primary-container: '#bfd2ff'
  inverse-primary: '#adc7ff'
  secondary: '#bc000c'
  on-secondary: '#ffffff'
  secondary-container: '#e80f16'
  on-secondary-container: '#fffbff'
  tertiary: '#752b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#9b3c00'
  on-tertiary-container: '#ffc5ac'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc7ff'
  on-primary-fixed: '#001a41'
  on-primary-fixed-variant: '#004493'
  secondary-fixed: '#ffdad5'
  secondary-fixed-dim: '#ffb4aa'
  on-secondary-fixed: '#410001'
  on-secondary-fixed-variant: '#930007'
  tertiary-fixed: '#ffdbcc'
  tertiary-fixed-dim: '#ffb695'
  on-tertiary-fixed: '#351000'
  on-tertiary-fixed-variant: '#7c2e00'
  background: '#fcf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e4e2e1'
typography:
  headline-xl:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  label-technical:
    fontFamily: Hanken Grotesk
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.05em
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 24px
  margin: 40px
  hairline: 0.5px
---

## Brand & Style
This design system is rooted in the "Less, but better" philosophy of Dieter Rams and the rigorous Swiss Style. It prioritizes clarity, objective functionality, and a stark, industrial aesthetic. The emotional response is one of calm reliability and technical precision.

The style is **Minimalist Functionalism**. It avoids all decorative flourishes, unnecessary shadows, or skeuomorphic depth. Instead, it relies on mathematical grids, purposeful alignment, and physical metaphors of hardware controls (dials, toggles, and switches) translated into flat, geometric UI. The interface should feel like a piece of high-end lab equipment or a classic Braun appliance: honest, durable, and unobtrusive.

## Colors
The palette is dominated by a warm, neutral foundation to evoke the matte plastics and metals of vintage industrial design. 

- **Primary (Braun Blue):** Used strictly for functional interaction. It indicates "active" states or primary actions. Use with extreme restraint.
- **Secondary (Signal Red):** Reserved for warnings, stop actions, or critical errors.
- **Neutral/Surface:** A warm off-white (#F2F0EB) serves as the primary canvas, with a slightly darker warm gray (#EBE9E4) for container divisions.
- **Ink:** A deep charcoal (#2D2D2D) is used for all text and iconography to maintain high legibility without the harshness of pure black.

## Typography
The typography follows the International Typographic Style (Swiss Style). **Hanken Grotesk** is utilized for its objective, neo-grotesque qualities similar to Akzidenz-Grotesk.

- **Strict Alignment:** All text must align to the baseline grid. 
- **Lowercase Priority:** Technical labels, metadata, and status indicators (e.g., "active", "ge_contract.yaml") must be set in lowercase to emphasize the "product as a tool" aesthetic.
- **Weights:** Use only Regular (400) and Bold (700) where possible. Medium (500/600) is used only for UI labels requiring immediate distinction.
- **Leading:** Precise leading (usually 1.5x font size for body) ensures vertical rhythm.

## Layout & Spacing
The layout is a "stark" 12-column grid. It uses visible vertical and horizontal lines to divide content, rather than shadows or varied background colors.

- **The Grid:** A fixed-width system for desktop to ensure precise control over element placement. 
- **Hairlines:** Divisions between modules are marked by 0.5pt (or 1px at 50% opacity) lines in the neutral ink color. 
- **Information Density:** High, but organized. Whitespace is used as a functional separator to group related controls.
- **Reflow:** On mobile, the 12-column grid collapses to 4 columns. All technical labels maintain their 11px size to preserve the "instrument" feel.

## Elevation & Depth
This system rejects traditional elevation. There are no shadows. 

Hierarchy is achieved through:
- **Tonal Layering:** Using the subtle shift from the background (#F2F0EB) to the surface (#EBE9E4).
- **Strokes:** All "containers" are defined by the 0.5pt hairline border.
- **Color Inversion:** Active states are indicated by the primary blue or by inverting the background and text colors (e.g., a black button with white text).
- **Geometric Insets:** Input fields and toggles use subtle 1px inner strokes to simulate the "milled" or "pressed" look of physical aluminum panels.

## Shapes
Shapes are strictly geometric. Circles are used for dials and radio-style toggles; rectangles with very small radii are used for cards and buttons.

- **Base Radius:** 0.25rem (4px) for most components to provide a "softened industrial" feel.
- **Circular Elements:** Strictly 1:1 aspect ratios for buttons that mimic physical knobs or push-buttons.
- **Ventilation Patterns:** Use repeating dots or lines as decorative/functional motifs to fill empty space, mimicking the speaker grilles of Braun radios.

## Components

- **Buttons:** Rectangular with a 4px radius. Default state is a hairline border. Primary state is solid Braun Blue with white text. No gradients.
- **Dials/Sliders:** Interactive elements should mimic physical hardware. Sliders use a single hairline track with a circular "knob" thumb.
- **Technical Labels:** Positioned directly above or below components in lowercase 11px Hanken Grotesk.
- **Status Indicators:** Simple 8px solid circles. Blue for "on," Gray for "off," Red for "error."
- **Input Fields:** No background color; defined only by a bottom hairline or a full 0.5pt border.
- **Cards:** Defined by a hairline stroke. No shadow. The header of the card is often separated by a horizontal line.
- **Toggle Switches:** Small, circular "nub" within a pill-shaped track, using high contrast (Neutral vs Surface) to indicate state.